# Ozeki WordPress Resilience

English | [日本語](RAADME-jp.md)

**Preserve WordPress information assets in S3 and reconstruct the supported site state in a new WordPress after losing the original server or database.**

Resilience is for WordPress maintainers who need independently stored content and an explicit recovery history. The operating database is not the only recovery source. Complete originals, metadata and confirmed operations remain in S3; recovery uses a trusted initial snapshot or independent Checkpoint plus later confirmed history.

This is on-demand reconstruction, not continuous replication or an infrastructure backup. It neither provisions servers nor switches DNS. A permanently running second EC2 instance is not required; an administrator prepares a suitable recovery WordPress when needed. Ozeki Database Backup for S3 is a separate product, not a dependency.

## Current package

The product is **0.3.1** (`packages/markdown-m1`). This candidate is `ozeki-wordpress-resilience-0.3.1-native-details-final.zip`, including the consolidated bilingual documentation and native article deletion, featured-image and category/tag support. Identify it by filename and the SHA-256 in its accompanying validation record. Formal release is deferred. The root 0.2.0 research plugin is not the current product.

## Design and recovery boundary

1. **Establish a trusted starting point.** The administrator judges the existing site suitable, pauses editing and creates a complete initial snapshot. It contains supported content, files, presentation state and selected runtime software.
2. **Save complete asset versions during normal use.** Markdown stays readable `.md`; native post/page bodies are complete HTML; supported adapter records use JSON; media remains files. Each update saves a complete version of the affected asset, not a content delta or a new whole-site inventory.
3. **Confirm successful operations in S3.** Protected article saves store the original before WordPress application. Native article detail/deletion operations, comments and the supported third-party adapters capture completed operation data instead. In both cases, WordPress persistence, S3 storage and formal-history confirmation must succeed before an operation is recoverable.
4. **Create independent Checkpoints.** The complete-site Checkpoint uses the prior S3 baseline and confirmed history, not a fresh read of the live site. It contains its own required resources, rather than only an inventory referencing old ancestors.
5. **Reconstruct when requested.** Download and verify the selected complete baseline and its subsequent history, then replace supported content on a prepared destination. The old server, old DB and local pending queue are not recovery inputs.

The administrator-trusted initial state and accepted save data are design assumptions, not malware-free certifications. Fixed S3 Version IDs and hashes verify stored identity; they do not prove that submitted content was harmless. The full baseline also captures selected theme/plugin code and content-table records as portable files/JSON; reconstruction is not a promise to reinstall every component from a clean official distribution.

Only **confirmed S3 formal history** extends a trusted baseline. Prepared originals are not automatically adopted. If the source is lost before confirmation, omit that operation: an unconfirmed new article is absent, and an unconfirmed update leaves the previous confirmed version.

Saved publication state, including `publish`, is reproduced. Internet exposure, server/network access and DNS remain administrator decisions. There is no product requirement to convert everything to drafts or obtain a separate publication approval.

## Supported content and plugins

| Source | Recorded and recovered scope | Important limits |
|---|---|---|
| WordPress Posts and Pages | Standard create/publish/update, body, title, slug, recorded attributes, parent/order, discussion settings, Trash/untrash, permanent deletion, featured-image set/replace/remove and category/tag assignments | No complete draft/scheduled-publication guarantee; global term administration, arbitrary metadata and menu/front-page/sticky deletion side effects excluded |
| Local images | Supported upload originals before registration; referenced originals/generated sizes, attachment information and alt text bound to an article version | JPEG/PNG/GIF/WebP/AVIF; 32 MiB per file. Unused media, external/CDN assets and arbitrary binary overwrite tools are not tracked |
| Core comments | Addition, edits, moderation, Trash/untrash, permanent deletion, replies and approved counts | Completed-operation capture; restore through site-wide recovery, not individual text recovery |
| **Ozeki Markdown Documents** | Normal editor; complete Markdown source, title, state and supported document links; Mermaid, math and code syntax preserved | Separate plugin required for Markdown and the current supplementary text-recovery path. Rendering needs compatible plugin/runtime; arbitrary external links and plugin relations are not a general migration guarantee |
| **Contact Form 7** | Completed form definitions and deletion, referenced form relationships | No mail replay; submission attachments and arbitrary extensions excluded |
| **Flamingo** | Received inquiries, fields/channels, later edits, spam/ham, Trash/restore and permanent deletion | No address-book or attachment recovery; request-end capture; deleting a form does not delete its inquiries |
| **WP-Members** | Core subscriber accounts, configured fields, approval, core settings and post/page restrictions; saved password hashes enable login | No privileged/custom roles, paid extensions, CAPTCHA secrets, sessions or profile-file uploads. Unrelated destination account collisions are rejected; administrators preserved |
| **TablePress** | Core tables, IDs, cells, options/visibility, display settings, add/update/delete and ID changes; article shortcodes | No premium modules, arbitrary external imports, personal editor preferences or same-table concurrency guarantee; restored custom CSS uses inline mode |

Tested optional versions include CF7 **6.2.3**, Flamingo **2.6.4**, WP-Members **3.5.8.1** and TablePress **3.4.1**. They are separately installed, not bundled in the Resilience ZIP. Capture a new trusted baseline after changing recorded runtime software; version compatibility is not inferred from a successful earlier test.

The **initial snapshot** also captures supported uploads (including the tested PDF), theme/parent theme, menus, templates, navigation, global styles and selected settings. This does **not** mean later changes to those resources are automatically tracked. Theme/menu/template/global taxonomy administration changes and unsupported plugin settings need a new trusted baseline. Not every installed plugin is covered.

## Prepare and use

1. Install the dedicated product ZIP in WordPress. The plugin declares WordPress 6.4+ and PHP 8.1+; this is not a test claim for every combination. The tested CF7 6.2.3 requires PHP 8.3+. Use InnoDB for managed content tables, ZipArchive and writable resource directories. Install the plugins required for the content you use.
2. Configure normal AWS SDK credentials on the server, preferably an EC2 instance role where available. No SSH credential helper, Python worker, shared bridge, Docker or custom editor is required by the product. Docker was used only as a test environment.
3. In **Tools → Resilience**, set bucket, region, dedicated prefix ending in `/` and optionally expected account owner/retention days. Enable S3 versioning. Specifying Object Lock retention requires a suitably configured existing bucket; the plugin does not configure IAM or bucket policies.
4. Grant prefix-scoped listing, fixed-version reads and writes (`ListBucket`, `GetObject`, `GetObjectVersion`, `PutObject`); Object Lock writes additionally require `PutObjectRetention`. Normal saving/recovery needs no delete or retention-bypass permission. Use one writing WordPress per prefix; the destination can use read-only S3 access.
5. Resolve pending history, pause source editing and create a trusted **complete site initial snapshot**. Enable protection for subsequent supported operations. Continue using normal WordPress/plugin interfaces.
6. Use the **site-wide** controls to create a manual complete Checkpoint. The older supplementary asset Checkpoint is not a complete site snapshot. Scheduled execution remains deferred.
7. Prepare a designated destination with a different URL, compatible WordPress release line, required plugins and S3 access; disable its write protection. Under **Site-wide recovery — primary workflow**, select a complete snapshot/Checkpoint and use **Restore complete site**. This replaces destination content and presentation state; do not run it on an unrelated active site.
8. Inspect the recorded result and verify content and required behavior. The administrator decides network exposure separately. When WP-Members moderated registration is used, verify that the designated administrator is activated on the source at setup and on the destination before recovery. Restoring membership settings does not activate destination administrators. After recovery, verify a fresh sign-in through the standard WordPress login screen; an existing session is not sufficient. Keep member moderation and other accounts unchanged.

**Individual recovery is supplementary:** select one formal version per asset under **Confirmed formal history / Individual recovery**. It restores text/attributes and matching identities while leaving unrelated content intact. It does not restore media files, themes, menus, comments or plugin-adapter state; use site-wide recovery for those.

## Failures, retention and limits

- Protected article original-storage failure prevents confirmed WordPress application; application/verification failure rolls back managed transactional data. Native editing keeps WordPress's standard editing controls; the additional stale-form token applies to the Markdown full editor.
- For post-success adapters, the source change can already be visible when S3 fails. **Resume history** retries frozen pending data; article confirmation checks the applied state. Do not claim all adapters intercept before the source write.
- A surviving source can resume pending history. Source loss with pending history does not make the final unconfirmed change recoverable. Cross-system atomic commit is not claimed.
- Keep the complete selected Checkpoint and every resource/history record needed after it. Older ancestors are unnecessary only once an independent complete recovery point and its tail are safely retained. Do not prune required versions with an unrelated lifecycle rule.
- Cleanup is optional and disabled by default. The existing supplementary asset-path cleanup has contract tests, not real-S3 deletion acceptance or a general complete-site cleanup guarantee. Do not infer scheduled complete-site operation from an asset-path timer. See the separate [asset Checkpoint/cleanup scope](docs/checkpoints.md).
- Source text is limited to 5 MiB valid UTF-8 without NUL. History listing scans the dedicated prefix and targets small deployments. Multiple writing installations and arbitrary concurrent changes to the same asset are unsupported.
- No universal plugin compatibility, server provisioning, network cutover, complete scheduling-state recovery or automatic replica synchronization. Source AWS/SMTP configuration, administrator credentials and sessions are not imported. WP-Members subscriber password hashes are an explicit supported exception to exclusion of account credentials.
- Recovery verifies resources before replacement and rolls back handled write failures. Process-kill recovery and automatic rollback after abrupt termination are not accepted guarantees. Arbitrary external side effects during save and untested object-cache combinations are not covered.

## Evidence and issue classification

[Combined final-ZIP acceptance](https://github.com/ozekihiroshi/ozeki-wordpress-resilience/blob/main/docs/releases/combined-final-m1-031.md): fresh install and update preserved settings/history; both installations reconstructed one real-S3 Checkpoint through 21 plus confirmed history through 29. Posts/Pages, images, comments, forms/receipts, member login/restrictions and tables matched. ZIP installation tests used extraction/activation and overwrite update, not browser Plugin_Upgrader. PHP 8.1/8.3 contract CI passed for the PR #26 code.

[TablePress browser acceptance](https://github.com/ozekihiroshi/ozeki-wordpress-resilience/blob/main/docs/releases/tablepress-browser-acceptance.md) additionally covers standard-editor add/update/delete and recovered search/sort/pagination. It does not establish browser acceptance for every adapter. [Native editor acceptance](https://github.com/ozekihiroshi/ozeki-wordpress-resilience/blob/main/docs/releases/native-m1-031.md) covers standard editing and images in Chrome; the in-app browser's blank editor iframe is a separate unresolved browser issue.

**Product correction:** CF7's exact known deny-all `uploads/wpcf7_uploads/.htaccess` is preserved. Other control/executable files remain rejected. **Environment/test infrastructure:** dm memory limits, proxy/fixture URL configuration, a reused test DB prefix and standalone test paths are recorded separately; they are not new product dependencies. Mail sending, scheduled execution, real-S3 cleanup and formal release remain deferred.

## Detailed documentation and history

[Complete site recovery](docs/site-snapshot.md) · [Comments](docs/comments.md) · [Forms](docs/forms.md) · [Membership](docs/members.md) · [TablePress](docs/tablepress.md) · [Combined scope](docs/combined.md)

[Preserved historical README and research instructions](https://github.com/ozekihiroshi/ozeki-wordpress-resilience/blob/main/docs/archive/readme-before-product-consolidation-20261024/package-en.md). Old 0.2.0 workers, private previews, draft-only targets and signing experiments are not current product requirements. Historical evidence remains available without defining the current product's completion conditions.

## Native article details

Permanent article deletion, featured-image selection/replacement/removal and category/tag assignment/removal now join confirmed S3 history and site-wide replay. The extension captures successful final operation state; it does not change article-body S3-first saving. Required thumbnail files and new category ancestors are preserved. Included in this native-details-final candidate. Global taxonomy administration, menu/front-page/sticky cleanup and arbitrary metadata remain excluded. See [scope and measured acceptance](docs/native-details.md).
## Recovery result display

The site-wide result shows success, failure or completion unconfirmed; the exact Checkpoint key and S3 Version ID; the Checkpoint history boundary and subsequent applied history range/count; restored post records and files written/replaced. Detailed JSON retains the latest attempt and last successful result. Post counts include all post types, not only public articles; unchanged files may be reused, so zero writes does not mean no recovered files. Failure/unfinished attempts do not reuse prior success counts and do not prove zero changes or completed rollback. A missing Checkpoint listing is reported as unavailable, not inferred. This local administrative result is not S3 formal history and is not a complete audit log.
