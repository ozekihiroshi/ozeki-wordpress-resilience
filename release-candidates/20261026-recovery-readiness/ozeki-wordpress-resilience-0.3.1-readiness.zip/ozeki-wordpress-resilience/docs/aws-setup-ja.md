# AWS設定 — 1サイト・1prefix・完全なポリシー

[English](aws-setup.md) · [利用ガイドへ戻る](user-guide-ja.md)

## 1. この例の構成と設定表

同一AWSアカウント、通常のS3汎用バケット（標準awsパーティション）、SSE-S3暗号化、EC2上のWordPressがインスタンスロールを使う構成です。WordPressにアクセスキーを保存しません。サンプルは製品のprefix操作用であり、環境構築権限・自由なコンソール閲覧権限ではありません。別アカウント、独自KMSキー、EC2以外のホスティングは担当者による別設計が必要です。

| 設定値 | 置換・記録する内容 |
|---|---|
| bucket | JSON中の **replace-with-your-bucketをすべて** 実バケット名に置換。s3://は付けない |
| prefix | JSON中の **sites/example-site/をすべて** 専用prefixに置換。末尾/を含める |
| region | バケットのリージョン（例ap-northeast-1）を控え、製品へ入力 |
| owner | バケット所有者の12桁AWSアカウントIDを控え、製品へ入力 |
| 保存側ロール | 元EC2に実際に付いているロール名を控える |
| 復旧側ロール | 別の読取り専用認証主体を控える |

例の名前は架空で、開発用S3ではありません。広範なS3権限が別に付いたロールにサンプルを追加しても、その既存Allowは狭まりません。これは完全な「製品専用のidentity policy」であり、アカウント全体の権限境界ではありません。Denyもこのprefixに限定します。他ポリシー、バケットポリシー、組織制限・権限境界も実効権限に影響します。

## 2. バケットを準備する

AWS担当者が環境構築用権限で実施します。以下の設定権限は製品ロールには与えません。

1. S3で利用を承認したバケットを選ぶか、必要なリージョンに用意します。専用prefixを使い、Block Public Accessは有効、ACLは無効（Bucket owner enforced）にします。復旧資源の公開アクセスは不要です。
2. **プロパティ→バケットのバージョニング→編集** で有効にし、リージョン・所有者を記録します。使用開始後にバージョニングを停止しません。[AWS公式手順](https://docs.aws.amazon.com/AmazonS3/latest/userguide/manage-versioning-examples.html)。
3. 本例はデフォルト暗号化 **SSE-S3** です。SSE-KMSを使う場合、キーポリシー・読書き権限・復旧時のキー利用可能性まで別途準備が必要です。
4. **管理→ライフサイクルルール** を確認します。製品の保持対象とは無関係に現行版・旧版を削除したり、取出し待ちが必要なアーカイブへ移したりするルールを対象prefixへ適用しないでください。古い画像でも最新復旧点に必要なことがあります。S3の経過日数ルールはこの依存関係を理解しません。
5. 任意のObject Lockを使うか決めます。単純な構成例では製品からロックを要求せず `retention_days=0` です。使う場合はバケットのObject Lock対応と計画に合う日数が必要です。製品の保存期限が過ぎても既存ロック・既定値で削除できない場合があり、0へ変更しても既存ロックは短縮されません。製品は保持・Legal Holdを回避しません。Object Lock有効化は簡単に戻せる切替ではなく、継続するバケット設定です。[AWS Object Lock](https://docs.aws.amazon.com/AmazonS3/latest/userguide/object-lock.html)。

バージョニングだけでは権限を持つ主体による固定版削除を防げません。一方、削除ロックの期限切れだけで資源が自動的に消えるわけでもありません。製品のGFS・詳細履歴期間が候補を決め、AWSのロック・IAMが削除可能性を決めます。

## 3. EC2標準認証を用意する

AWS SDK PHPの標準認証チェーンはEC2インスタンスプロファイルから一時認証情報を取得できます。他の認証設定が優先される場合もあるため、シェルだけでなくWebのPHPが実際に使う認証を確認します。[AWS標準認証の説明](https://docs.aws.amazon.com/sdk-for-php/v3/developer-guide/guide_credentials_default_chain.html)。

**EC2→インスタンス→対象→アクション→セキュリティ→IAMロールを変更** で確認します。既に運用ロールがあるならロール自体は維持し、次節の製品専用ポリシーだけを編集します。既存ロールを置換して他のサービスの権限を失わないでください。初めてロールを用意する場合、IAMの信頼されたエンティティは **AWSのサービス→EC2** を使い、選んだ製品ポリシーを設定します。復旧先に保存用ロールを流用しません。[AWS公式の関連付け手順](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/attach-iam-role.html)。

WebのPHPから標準メタデータサービスへ到達できる必要があります。コンテナではホストと到達性・応答ホップ数の条件が異なる場合があります。サーバ担当者に確認し、IMDSv2を無効化したり認証中継を増設したりして回避しません。EC2以外にもSDK標準認証はありますが、このガイドで未検証ホスティングの利用可否を保証しません。製品に秘密鍵入力欄はありません。

## 4. 完全なJSONを一つ選び、差し替える

ファイルを取得し、設定表の値をすべて置き換えて、**JSON全文を貼り替えます**。断片の追記・手作業での結合は不要です。保存側の二種類を同時に付けません。

| 完全なJSON | 用途 |
|---|---|
| [source-no-delete.json](aws-examples/source-no-delete.json) | 保存・再取得・Checkpoint作成・全版プレビュー。固定版削除は明示的Deny。最初はこちら |
| [source-with-cleanup.json](aws-examples/source-with-cleanup.json) | 上記に加え専用prefix内の固定版削除。保持規則に従う削除を利用するときに選択 |
| [recovery-read-only.json](aws-examples/recovery-read-only.json) | 一覧・原本／固定版・ロック読取り。オブジェクト変更を明示的Deny。復旧先はこちら |

保存側には任意ロック用のPutObjectRetentionを含みます。どちらもLegal Hold変更・保持回避を許可しません。削除許可版でも版を指定しないDeleteObjectは拒否し、削除マーカーを作って済ませることはできません。ListBucket／ListBucketVersionsはバケットARNとprefix条件、オブジェクト操作は対象prefixのARNで限定します。HeadObjectというIAM Actionはなく、GetObject／GetObjectVersionで対応します。[AWS操作別権限](https://docs.aws.amazon.com/AmazonS3/latest/userguide/using-with-s3-policy-actions.html)。

AWSコンソールでの手順：

1. **IAM→ロール→記録した保存側または復旧側ロール→許可** を開きます。対象ホストの実際のロールか確認します。
2. 製品専用ポリシーが既にあれば開き、**編集→JSON** で置換済みの全文を貼り替えます。管理ポリシーなら新しい版をデフォルトとして保存、インラインなら編集を保存します。変更のたびにポリシーを追加しません。
3. 初回で専用ポリシーがない場合だけ、一つの製品専用インラインポリシーを全文JSONから作ります。次回から同じものを差し替えます。他サービスの権限を含む共有ポリシーは上書きせず、担当者に製品用範囲を分けてもらいます。
4. bucket・prefix・Actionを確認して保存します。s3:*、全バケット指定、IAM管理権限、ロック回避は不要です。
5. 後から削除を有効にする場合、同じポリシーをsource-no-deleteからsource-with-cleanupへ全文差替えします。別ポリシーに対象範囲への明示的Denyがあれば引き続き拒否されます。Allowを足しても解除できません。共有Denyを無造作に外さず、担当者と対象範囲を整理してください。復旧側は読取り専用のままです。

サンプルはLifecycle・バケット設定・バケットポリシーを変更せず、EC2・IAMの管理権限も付与しません。S3コンソールのルート一覧には別の利用者権限が必要な場合があります。コンソール閲覧のために製品ロールを広げないでください。

## 5. シェルだけでなく製品から確認する

[Baseline作成](user-guide-ja.md)へ戻ります。設定保存後、完全初期スナップショットの成功で製品実行環境からの書込み・固定版再取得を確認します。通常編集の履歴確定で履歴、プレビューで削除せず全版・ロック読取り、別の読取り専用復旧先で再構築を確認します。ポリシー保存や別セッションのaws sts get-caller-identity成功だけで、これらまで合格にしません。

AccessDeniedなら操作・正確な範囲を記録し、実行主体、置換漏れ、明示的Deny、バケット／KMS条件、環境認証を確認します。AdministratorAccessを製品の回避策にしません。保持期限中・Legal Holdは削除保留の条件で、回避要求ではありません。通信不能・不明エラーを「ロック設定なし」とは扱いません。

サンプルは現行呼出しとAWS文書に基づく静的確認（2026-10-26）のみで、新たにAWSへ適用していません。後続の[初回導入試験](https://github.com/ozekihiroshi/ozeki-wordpress-resilience/blob/main/docs/releases/user-guide-onboarding.md)は既存EC2ロールを使用し、このJSONそのものを適用していません。保存側はより広い権限を持ち、復旧側はListBucketVersionsが不足していても今回の復旧に成功しました。サンプルの実適用検証とは区別します。[残る確認事項](remaining-confirmations.md)も参照。設定表と読取り専用の復旧準備手順は元サーバ外にも控え、認証情報を文書や問い合わせへ載せないでください。
